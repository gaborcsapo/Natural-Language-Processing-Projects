##Instructions

Type python program_phone.py/program_dollar.py <name of input file without .txt> <name of output file without .txt>

Example:
python program_phone.py test_dollar_phone results